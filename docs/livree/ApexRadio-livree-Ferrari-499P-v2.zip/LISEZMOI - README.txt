LIVREE APEX RADIO - FERRARI 499P HYPERCAR (2025) - Le Mans Ultimate
================================================================
Gratuite, par lolotuner (Apex Radio) - version 2 : logos APEX//RADIO bien visibles des deux cotes

INSTALLATION
1. Copie les deux fichiers dans : ...\steamapps\common\Le Mans Ultimate\UserData\Liveries
   Renomme customskin_Ferrari_499P.tga en : customskin.tga
   Renomme customskin_region_Ferrari_499P.tga en : customskin_region.tga
2. Dans LMU : Equipes -> Livrees -> Livrees personnalisees, choisis ton equipe.
3. Appliquer a une nouvelle voiture -> Ferrari 499P (2025) -> Showroom.
4. Clique sur RELOAD, puis UPLOAD pour l'envoyer a la validation de LMU (RaceControl Pro).

----------------------------------------------------------------
Free, by lolotuner (Apex Radio) - version 2: APEX//RADIO logos clearly visible on both sides
1. Copy both files into ...\Le Mans Ultimate\UserData\Liveries,
   rename them customskin.tga and customskin_region.tga
2. In LMU: Teams -> Liveries -> Custom liveries, pick your team.
3. Apply to a new car -> Ferrari 499P (2025) -> Showroom.
4. Click RELOAD, then UPLOAD to send it for LMU validation (RaceControl Pro).
