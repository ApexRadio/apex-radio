LIVREES APEX RADIO - MERCEDES-AMG LMGT3 (2025) WEC et ELMS - Le Mans Ultimate
================================================================================
Gratuites, par lolotuner (Apex Radio)

  - customskin_Mercedes_AMG_GT3.tga + customskin_region_Mercedes_AMG_GT3.tga           -> Mercedes-AMG LMGT3 (2025)
  - customskin_Mercedes_AMG_GT3_ELMS.tga + customskin_region_Mercedes_AMG_GT3_ELMS.tga -> Mercedes-AMG LMGT3 ELMS (2025)

INSTALLATION
1. Copie les deux fichiers de ta version dans :
   ...\steamapps\common\Le Mans Ultimate\UserData\Liveries
   Renomme la livree en : customskin.tga
   Renomme la carte des zones (customskin_region_...) en : customskin_region.tga
2. Dans LMU : Equipes -> Livrees -> Livrees personnalisees, choisis ton equipe.
3. Appliquer a une nouvelle voiture -> Mercedes-AMG LMGT3 (ou sa version ELMS) -> Showroom.
4. Clique sur RELOAD : la livree apparait. Clique sur UPLOAD pour l'envoyer a la validation de LMU (RaceControl Pro).
LMU ne lit qu'une livree a la fois : fais une version, envoie-la, puis l'autre.

--------------------------------------------------------------------------------
Free, by lolotuner (Apex Radio)
1. Copy both files for your version into ...\Le Mans Ultimate\UserData\Liveries,
   rename the livery to customskin.tga and the region map to customskin_region.tga
2. In LMU: Teams -> Liveries -> Custom liveries, pick your team.
3. Apply to a new car -> Mercedes-AMG LMGT3 (or its ELMS version) -> Showroom.
4. Click RELOAD, then UPLOAD to send it for LMU validation (RaceControl Pro).
