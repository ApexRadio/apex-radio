LIVREE APEX RADIO - ORECA 07 (LMP2) - Le Mans Ultimate
=====================================================
Gratuite, par lolotuner (Apex Radio) - https://discord.gg/ZHg4qXd26g

Deux versions :
  - customskin_WEC.tga  -> Oreca 07 LMP2 (WEC)
  - customskin_ELMS.tga -> Oreca 07 LMP2 (ELMS)

INSTALLATION
1. Copie le fichier de ta version dans le dossier du jeu :
   ...\steamapps\common\Le Mans Ultimate\UserData\Liveries
   et renomme-le en : customskin.tga
2. Dans LMU : Equipes -> Livrees -> Livrees personnalisees, choisis ton equipe.
3. Appliquer a une nouvelle voiture -> Oreca 07 (WEC ou ELMS selon le fichier) -> Showroom.
4. Clique sur RELOAD : la livree apparait. Clique sur UPLOAD pour l'envoyer a la validation de LMU.
LMU ne lit qu'un seul customskin.tga a la fois : fais une version, envoie-la, puis l'autre.

-----------------------------------------------------
APEX RADIO LIVERY - ORECA 07 (LMP2) - Le Mans Ultimate
Free, by lolotuner (Apex Radio)

1. Copy the file for your car version into ...\Le Mans Ultimate\UserData\Liveries and rename it customskin.tga
2. In LMU: Teams -> Liveries -> Custom liveries, pick your team.
3. Apply to a new car -> Oreca 07 (WEC or ELMS) -> Showroom.
4. Click RELOAD, then UPLOAD to send it for LMU validation.
