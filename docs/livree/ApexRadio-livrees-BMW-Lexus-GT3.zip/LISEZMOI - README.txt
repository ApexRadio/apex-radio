LIVREES APEX RADIO - BMW M4 LMGT3 et LEXUS RC F LMGT3 (2025) - Le Mans Ultimate
================================================================================
Gratuites, par lolotuner (Apex Radio)

  - customskin_BMW_M4_GT3.tga   -> BMW M4 LMGT3 (2025)
  - customskin_Lexus_RCF_GT3.tga -> Lexus RC F LMGT3 (2025)

INSTALLATION
1. Copie le fichier de ta voiture dans :
   ...\steamapps\common\Le Mans Ultimate\UserData\Liveries
   et renomme-le en : customskin.tga
   Copie aussi le fichier customskin_region_... de la meme voiture et renomme-le en : customskin_region.tga
   (il indique au jeu ou sont le carbone et les autocollants)
2. Dans LMU : Equipes -> Livrees -> Livrees personnalisees, choisis ton equipe.
3. Appliquer a une nouvelle voiture -> BMW M4 LMGT3 ou Lexus RC F LMGT3 (2025) -> Showroom.
4. Clique sur RELOAD : la livree apparait. Clique sur UPLOAD pour l'envoyer a la validation de LMU.
LMU ne lit qu'un seul customskin.tga a la fois : fais une voiture, envoie-la, puis l'autre.

--------------------------------------------------------------------------------
APEX RADIO LIVERIES - BMW M4 LMGT3 and LEXUS RC F LMGT3 (2025) - Le Mans Ultimate
Free, by lolotuner (Apex Radio)

1. Copy the file for your car into ...\Le Mans Ultimate\UserData\Liveries and rename it customskin.tga
   Also copy the matching customskin_region_... file and rename it customskin_region.tga
2. In LMU: Teams -> Liveries -> Custom liveries, pick your team.
3. Apply to a new car -> BMW M4 LMGT3 or Lexus RC F LMGT3 (2025) -> Showroom.
4. Click RELOAD, then UPLOAD to send it for LMU validation.
