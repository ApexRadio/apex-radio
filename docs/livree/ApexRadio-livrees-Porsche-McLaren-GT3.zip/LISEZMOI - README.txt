LIVREES APEX RADIO - PORSCHE 911 GT3 R LMGT3 et McLAREN 720S LMGT3 EVO (2025) - Le Mans Ultimate
================================================================================
Gratuites, par lolotuner (Apex Radio)

  - customskin_Porsche_911_GT3R.tga + customskin_region_Porsche_911_GT3R.tga -> Porsche 911 GT3 R LMGT3 (2025)
  - customskin_McLaren_720S_EVO.tga + customskin_region_McLaren_720S_EVO.tga -> McLaren 720S LMGT3 EVO (2025)

INSTALLATION
1. Copie les deux fichiers de ta voiture dans :
   ...\steamapps\common\Le Mans Ultimate\UserData\Liveries
   Renomme la livree en : customskin.tga
   Renomme la carte des zones (customskin_region_...) en : customskin_region.tga
2. Dans LMU : Equipes -> Livrees -> Livrees personnalisees, choisis ton equipe.
3. Appliquer a une nouvelle voiture -> Porsche 911 GT3 R ou McLaren 720S EVO (2025) -> Showroom.
4. Clique sur RELOAD : la livree apparait. Clique sur UPLOAD pour l'envoyer a la validation de LMU (RaceControl Pro).
LMU ne lit qu'une livree a la fois : fais une voiture, envoie-la, puis l'autre.

--------------------------------------------------------------------------------
Free, by lolotuner (Apex Radio)
1. Copy both files for your car into ...\Le Mans Ultimate\UserData\Liveries,
   rename the livery to customskin.tga and the region map to customskin_region.tga
2. In LMU: Teams -> Liveries -> Custom liveries, pick your team.
3. Apply to a new car -> Porsche 911 GT3 R or McLaren 720S EVO (2025) -> Showroom.
4. Click RELOAD, then UPLOAD to send it for LMU validation (RaceControl Pro).
